# Indian Posts Salary Calculator (Android APK Generator)

This repository automatically builds an Android APK using GitHub Actions.

## How it works:
1. Push `index.html` to this repository.
2. GitHub Actions runs `.github/workflows/build.yml`.
3. Download the compiled `app-debug.apk` from the Actions tab.
